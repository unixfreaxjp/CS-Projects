Homework 2 Readme

Files:
main.cpp - main method, drawing, and keyboard handling
CTM.cpp/CTM.h - class to manage the CTM and transformations
PlyModel.cpp/PlyModel.h - A class that can read and hold information read from a PLY file
vshader1.glsl - vertex shader
fshader1.glsl - fragment shader  that can be toggled to use a color array or uniform color
Grammer.cpp/Grammer.h - class that reads and evaluates l-system files
Turtle.cpp/turtle.h - class that handles the 'turtle' functionality.